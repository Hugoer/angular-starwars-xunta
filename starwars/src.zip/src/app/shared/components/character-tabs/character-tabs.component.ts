import { Component } from '@angular/core';

@Component({
  selector: 'app-character-tabs',
  imports: [],
  templateUrl: './character-tabs.component.html',
  styleUrl: './character-tabs.component.scss'
})
export class CharacterTabsComponent {

}
