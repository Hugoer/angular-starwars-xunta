import { ScaleOnHoverDirective } from './scale-on-hover.directive';

describe('ScaleOnHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new ScaleOnHoverDirective();
    expect(directive).toBeTruthy();
  });
});
